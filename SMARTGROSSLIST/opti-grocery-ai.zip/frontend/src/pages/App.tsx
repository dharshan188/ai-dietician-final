import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { ThemeToggle } from "components/ThemeToggle";
import {
  Loader2,
  User,
  HeartPulse,
  Apple,
  Wind,
  CookingPot,
  ClipboardCopy,
  Printer,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import brain from "brain";
import { HealthProfile, GroceryListResponse } from "brain/data-contracts";

function App() {
  const [formData, setFormData] = useState<HealthProfile>({
    age: 30,
    gender: "Male",
    height: 175,
    weight: 70,
    activityLevel: "Moderately Active",
    systolicBP: 120,
    diastolicBP: 80,
    bloodSugar: 90,
    cholesterol: 180,
    dietaryGoals: "Weight Management",
    dietaryRestrictions: "None",
    preferredCuisines: "Mediterranean",
    budgetLevel: "Medium",
    regionalSeasonalAvailability: "Temperate",
    mealPlanDuration: "Weekly",
    region: "USA",
    weather: "Mild",
  });
  const [groceryList, setGroceryList] = useState<GroceryListResponse | null>(
    null,
  );
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>,
  ) => {
    const { id, value } = e.target;
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSelectChange = (id: string, value: string) => {
    setFormData((prev) => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setGroceryList(null);

    try {
      const response = await brain.generate_grocery_list(formData);
      if (response.ok) {
        const data = await response.json();
        setGroceryList(data);
      } else {
        const errorData = await response.text();
        setError(
          `Failed to generate grocery list. Server responded with: ${errorData}`,
        );
      }
    } catch (err) {
      setError("An unexpected error occurred. Please try again later.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (groceryList) {
      const listText =
        groceryList.groceryList
          ?.map(
            (category) =>
              `${category.category}:\n` +
              category.items?.map((item) => `- ${item.name}: ${item.quantity}`).join("\n"),
          )
          .join("\n\n") || "";
      navigator.clipboard.writeText(listText);
      // You could add a toast notification here to confirm the copy
    }
  };

  const printList = () => {
    window.print();
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  const listContainerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const listItemVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 },
  };

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground transition-colors duration-300">
      <header className="sticky top-0 z-50 w-full border-b backdrop-blur-md bg-card/80">
        <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
          <div className="flex items-center gap-2">
            <Apple className="h-8 w-8 text-green-500" />
            <span className="text-xl font-bold">NutriGuard AI</span>
          </div>
          <div className="flex items-center gap-4">
            <nav className="hidden md:flex gap-6">
              <a
                href="#"
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Dashboard
              </a>
              <a
                href="#"
                className="text-sm font-medium text-primary underline"
              >
                Planner
              </a>
              <a
                href="#"
                className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
              >
                Settings
              </a>
            </nav>
            <ThemeToggle />
          </div>
        </div>
      </header>

      <main className="flex-grow p-4 sm:p-6 md:p-8">
        <div className="container mx-auto">
          <div className="text-center mb-10">
            <h1 className="text-3xl sm:text-4xl font-bold text-green-600 dark:text-green-500">
              OptiGrocery Planner
            </h1>
            <p className="mt-2 text-lg text-muted-foreground">
              Your personalized, health-optimized grocery list generator.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            {/* Form Section */}
            <motion.div
              variants={cardVariants}
              initial="hidden"
              animate="visible"
              className="lg:col-span-2"
            >
              <Card className="bg-card/70 backdrop-blur-xl">
                <CardHeader>
                  <CardTitle>Create Your Health Profile</CardTitle>
                  <CardDescription>
                    Provide your details to get a personalized grocery list.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-8">
                    {/* Personal Info */}
                    <div className="space-y-4">
                      <h3 className="flex items-center gap-2 text-lg font-semibold">
                        <User className="h-5 w-5 text-primary" />
                        Personal Info
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="age">Age</Label>
                          <Input
                            id="age"
                            type="number"
                            value={formData.age}
                            onChange={handleInputChange}
                            placeholder="e.g., 30"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="gender">Gender</Label>
                          <Select
                            onValueChange={(value) =>
                              handleSelectChange("gender", value)
                            }
                            defaultValue={formData.gender}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Male">Male</SelectItem>
                              <SelectItem value="Female">Female</SelectItem>
                              <SelectItem value="Other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="height">Height (cm)</Label>
                          <Input
                            id="height"
                            type="number"
                            value={formData.height}
                            onChange={handleInputChange}
                            placeholder="e.g., 175"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weight">Weight (kg)</Label>
                          <Input
                            id="weight"
                            type="number"
                            value={formData.weight}
                            onChange={handleInputChange}
                            placeholder="e.g., 70"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    {/* Health Metrics */}
                    <div className="space-y-4">
                      <h3 className="flex items-center gap-2 text-lg font-semibold">
                        <HeartPulse className="h-5 w-5 text-primary" />
                        Health Metrics
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="systolicBP">Systolic BP</Label>
                          <Input
                            id="systolicBP"
                            type="number"
                            value={formData.systolicBP}
                            onChange={handleInputChange}
                            placeholder="e.g., 120"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="diastolicBP">Diastolic BP</Label>
                          <Input
                            id="diastolicBP"
                            type="number"
                            value={formData.diastolicBP}
                            onChange={handleInputChange}
                            placeholder="e.g., 80"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="bloodSugar">Blood Sugar</Label>
                          <Input
                            id="bloodSugar"
                            type="number"
                            value={formData.bloodSugar}
                            onChange={handleInputChange}
                            placeholder="e.g., 90"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cholesterol">Cholesterol</Label>
                          <Input
                            id="cholesterol"
                            type="number"
                            value={formData.cholesterol}
                            onChange={handleInputChange}
                            placeholder="e.g., 180"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    {/* Preferences & Planning */}
                    <div className="space-y-4">
                      <h3 className="flex items-center gap-2 text-lg font-semibold">
                        <CookingPot className="h-5 w-5 text-primary" />
                        Preferences & Planning
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="activityLevel">
                            Activity Level
                          </Label>
                          <Select
                            onValueChange={(value) =>
                              handleSelectChange("activityLevel", value)
                            }
                            defaultValue={formData.activityLevel}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select level" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Sedentary">
                                Sedentary
                              </SelectItem>
                              <SelectItem value="Lightly Active">
                                Lightly Active
                              </SelectItem>
                              <SelectItem value="Moderately Active">
                                Moderately Active
                              </SelectItem>
                              <SelectItem value="Very Active">
                                Very Active
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="dietaryGoals">Dietary Goals</Label>
                          <Input
                            id="dietaryGoals"
                            value={formData.dietaryGoals}
                            onChange={handleInputChange}
                            placeholder="e.g., Weight Management"
                            required
                          />
                        </div>
                        <div className="space-y-2 col-span-2">
                          <Label htmlFor="dietaryRestrictions">
                            Dietary Restrictions
                          </Label>
                          <Input
                            id="dietaryRestrictions"
                            value={formData.dietaryRestrictions}
                            onChange={handleInputChange}
                            placeholder="e.g., Gluten-Free, Low Sodium"
                            required
                          />
                        </div>
                        <div className="space-y-2 col-span-2">
                          <Label htmlFor="preferredCuisines">
                            Preferred Cuisines
                          </Label>
                          <Input
                            id="preferredCuisines"
                            value={formData.preferredCuisines}
                            onChange={handleInputChange}
                            placeholder="e.g., Indian, Mediterranean"
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="budgetLevel">Budget Level</Label>
                          <Select
                            onValueChange={(value) =>
                              handleSelectChange("budgetLevel", value)
                            }
                            defaultValue={formData.budgetLevel}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select budget" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Low">Low</SelectItem>
                              <SelectItem value="Medium">Medium</SelectItem>
                              <SelectItem value="High">High</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="mealPlanDuration">
                            Meal Plan Duration
                          </Label>
                          <Select
                            onValueChange={(value) =>
                              handleSelectChange("mealPlanDuration", value)
                            }
                            defaultValue={formData.mealPlanDuration}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select duration" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Weekly">Weekly</SelectItem>
                              <SelectItem value="Monthly">Monthly</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>

                    {/* Contextual Factors */}
                    <div className="space-y-4">
                      <h3 className="flex items-center gap-2 text-lg font-semibold">
                        <Wind className="h-5 w-5 text-primary" />
                        Contextual Factors
                      </h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="region">Region / Culture</Label>
                          <Input
                            id="region"
                            value={formData.region}
                            onChange={handleInputChange}
                            placeholder="e.g., North India"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="weather">Current Weather</Label>
                          <Input
                            id="weather"
                            value={formData.weather}
                            onChange={handleInputChange}
                            placeholder="e.g., Hot, Cold"
                          />
                        </div>
                      </div>
                    </div>

                    <Button
                      type="submit"
                      className="w-full transition-all duration-300 hover:shadow-lg hover:scale-105"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Generating...
                        </>
                      ) : (
                        "Generate My List"
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </motion.div>

            {/* Results Section */}
            <div className="lg:col-span-3 space-y-8">
              <AnimatePresence>
                {isLoading && (
                  <motion.div
                    key="loader"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex justify-center items-center h-full"
                  >
                    <Loader2 className="h-16 w-16 text-primary animate-spin" />
                  </motion.div>
                )}
                {error && (
                  <motion.div key="error" variants={cardVariants} initial="hidden" animate="visible">
                    <Card className="bg-destructive/20 border-destructive text-destructive-foreground backdrop-blur-xl">
                      <CardHeader>
                        <CardTitle>Error</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p>{error}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
                {groceryList && (
                  <motion.div
                    key="groceries"
                    variants={cardVariants}
                    initial="hidden"
                    animate="visible"
                  >
                    <Card className="bg-card/70 backdrop-blur-xl">
                      <CardHeader className="flex flex-row items-center justify-between">
                        <CardTitle>Your Personalized Grocery List</CardTitle>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={copyToClipboard}
                            aria-label="Copy to clipboard"
                          >
                            <ClipboardCopy className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={printList}
                            aria-label="Print list"
                          >
                            <Printer className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <motion.div
                          variants={listContainerVariants}
                          initial="hidden"
                          animate="visible"
                          className="space-y-6"
                        >
                          {groceryList.groceryList?.map((category) => (
                            <motion.div
                              key={category.category}
                              variants={listItemVariants}
                              className="space-y-3"
                            >
                              <h3 className="text-xl font-semibold mb-3 text-primary">
                                {category.category}
                              </h3>
                              <div className="space-y-3">
                                {category.items?.map((item, index) => (
                                  <motion.div
                                    key={index}
                                    variants={listItemVariants}
                                    className="flex items-center space-x-3 group"
                                  >
                                    <Checkbox
                                      id={`${category.category}-${index}`}
                                    />
                                    <Label
                                      htmlFor={`${category.category}-${index}`}
                                      className="text-base font-normal group-hover:text-primary transition-colors"
                                    >
                                      <span className="font-medium">
                                        {item.name}
                                      </span>
                                      : {item.quantity}
                                    </Label>
                                  </motion.div>
                                ))}
                              </div>
                            </motion.div>
                          ))}
                        </motion.div>
                      </CardContent>
                      <CardFooter>
                        <CardDescription>
                          This list is optimized for your health goals. Happy
                          shopping!
                        </CardDescription>
                      </CardFooter>
                    </Card>
                  </motion.div>
                )}
                {!isLoading && !groceryList && !error && (
                  <motion.div key="placeholder" variants={cardVariants} initial="hidden" animate="visible" className="h-full">
                    <Card className="bg-card/70 backdrop-blur-xl flex flex-col items-center justify-center h-full text-center p-8">
                      <CardHeader>
                        <CardTitle>Ready to Shop Smart?</CardTitle>
                      </CardHeader>
                      <CardContent className="flex flex-col items-center">
                        <img
                          src="https://images.unsplash.com/photo-1542838132-92c53300491e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1974&q=80"
                          alt="Fresh groceries"
                          className="rounded-lg mb-6 w-full max-w-sm object-cover"
                        />
                        <p className="text-muted-foreground">
                          Fill out your profile on the left to get started.
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </main>
      <footer className="mt-auto border-t bg-card/80 backdrop-blur-md">
        <div className="container mx-auto py-4 px-4 md:px-6 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} NutriGuard AI. All Rights Reserved.
        </div>
      </footer>
    </div>
  );
}

export default App;
