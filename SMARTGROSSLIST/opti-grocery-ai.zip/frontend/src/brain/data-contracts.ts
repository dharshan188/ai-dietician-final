/** GroceryCategory */
export interface GroceryCategory {
  /**
   * Category
   * @example "Proteins"
   */
  category: string;
  /** Items */
  items: GroceryItem[];
}

/** GroceryItem */
export interface GroceryItem {
  /**
   * Name
   * @example "Chicken Breast"
   */
  name: string;
  /**
   * Quantity
   * @example "500g"
   */
  quantity: string;
}

/** GroceryListResponse */
export interface GroceryListResponse {
  /** Grocerylist */
  groceryList: GroceryCategory[];
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthProfile */
export interface HealthProfile {
  /**
   * Age
   * @example 35
   */
  age: number;
  /**
   * Gender
   * @example "Female"
   */
  gender: string;
  /**
   * Height
   * @example 165
   */
  height: number;
  /**
   * Weight
   * @example 70
   */
  weight: number;
  /**
   * Activitylevel
   * @example "Moderately Active"
   */
  activityLevel: string;
  /**
   * Systolicbp
   * @example 120
   */
  systolicBP: number;
  /**
   * Diastolicbp
   * @example 80
   */
  diastolicBP: number;
  /**
   * Bloodsugar
   * @example 90
   */
  bloodSugar: number;
  /**
   * Cholesterol
   * @example 200
   */
  cholesterol: number;
  /**
   * Dietarygoals
   * @example "Weight Management"
   */
  dietaryGoals: string;
  /**
   * Dietaryrestrictions
   * @example "None"
   */
  dietaryRestrictions: string;
  /**
   * Preferredcuisines
   * @example "Mediterranean"
   */
  preferredCuisines: string;
  /**
   * Budgetlevel
   * @example "Medium"
   */
  budgetLevel: string;
  /**
   * Regionalseasonalavailability
   * @example "Temperate"
   */
  regionalSeasonalAvailability: string;
  /**
   * Mealplanduration
   * @example "Weekly"
   */
  mealPlanDuration: string;
  /**
   * Region
   * @example "North India"
   */
  region?: string | null;
  /**
   * Weather
   * @example "Cold"
   */
  weather?: string | null;
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

export type CheckHealthData = HealthResponse;

export type GenerateGroceryListData = GroceryListResponse;

export type GenerateGroceryListError = HTTPValidationError;
