import { CheckHealthData, GenerateGroceryListData, GenerateGroceryListError, HealthProfile } from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * @description Generates a personalized grocery list based on the user's health profile. NOTE: This is a mock implementation that returns a dynamic, static grocery list based on region and budget for hackathon purposes.
   *
   * @tags dbtn/module:grocery_list
   * @name generate_grocery_list
   * @summary Generate Grocery List
   * @request POST:/routes/generate-grocery-list
   */
  generate_grocery_list = (data: HealthProfile, params: RequestParams = {}) =>
    this.request<GenerateGroceryListData, GenerateGroceryListError>({
      path: `/routes/generate-grocery-list`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });
}
