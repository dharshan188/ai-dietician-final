import { CheckHealthData, GenerateGroceryListData, HealthProfile } from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * @description Generates a personalized grocery list based on the user's health profile. NOTE: This is a mock implementation that returns a dynamic, static grocery list based on region and budget for hackathon purposes.
   * @tags dbtn/module:grocery_list
   * @name generate_grocery_list
   * @summary Generate Grocery List
   * @request POST:/routes/generate-grocery-list
   */
  export namespace generate_grocery_list {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = HealthProfile;
    export type RequestHeaders = {};
    export type ResponseBody = GenerateGroceryListData;
  }
}
