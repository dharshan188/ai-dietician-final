from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import List, Optional
import databutton as db
from openai import OpenAI


router = APIRouter()

# --- Pydantic Models ---

class HealthProfile(BaseModel):
    age: int = Field(..., example=35)
    gender: str = Field(..., example="Female")
    height: int = Field(..., example=165)
    weight: int = Field(..., example=70)
    activity_level: str = Field(..., example="Moderately Active", alias="activityLevel")
    systolic_bp: int = Field(..., example=120, alias="systolicBP")
    diastolic_bp: int = Field(..., example=80, alias="diastolicBP")
    blood_sugar: int = Field(..., example=90, alias="bloodSugar")
    cholesterol: int = Field(..., example=200)
    dietary_goals: str = Field(..., example="Weight Management", alias="dietaryGoals")
    dietary_restrictions: str = Field(..., example="None", alias="dietaryRestrictions")
    preferred_cuisines: str = Field(..., example="Mediterranean", alias="preferredCuisines")
    budget_level: str = Field(..., example="Medium", alias="budgetLevel")
    regional_seasonal_availability: str = Field(..., example="Temperate", alias="regionalSeasonalAvailability")
    meal_plan_duration: str = Field(..., example="Weekly", alias="mealPlanDuration")
    # New fields for more personalized recommendations
    region: Optional[str] = Field(None, example="North India")
    weather: Optional[str] = Field(None, example="Cold")

class GroceryItem(BaseModel):
    name: str = Field(..., example="Chicken Breast")
    quantity: str = Field(..., example="500g")

class GroceryCategory(BaseModel):
    category: str = Field(..., example="Proteins")
    items: List[GroceryItem]

class GroceryListResponse(BaseModel):
    grocery_list: List[GroceryCategory] = Field(..., alias="groceryList")


# --- OpenAI Client ---
# Initialize the OpenAI client
# The OPENAI_API_KEY is fetched from Databutton secrets
client = OpenAI(api_key=db.secrets.get("OPENAI_API_KEY"))


# --- API Endpoint ---

@router.post("/generate-grocery-list", response_model=GroceryListResponse)
def generate_grocery_list(profile: HealthProfile):
    """
    Generates a personalized grocery list based on the user's health profile.
    
    NOTE: This is a mock implementation that returns a dynamic, static grocery list
    based on region and budget for hackathon purposes.
    """
    
    # --- Mock Data Sets ---
    
    indian_grocery_list = {
        "groceryList": [
            {"category": "Vegetables", "items": [{"name": "Onion", "quantity": "1kg"}, {"name": "Tomato", "quantity": "1kg"}, {"name": "Ginger", "quantity": "100g"}, {"name": "Garlic", "quantity": "100g"}, {"name": "Potatoes", "quantity": "1kg"}]},
            {"category": "Fruits", "items": [{"name": "Bananas", "quantity": "1 dozen"}, {"name": "Mangoes", "quantity": "1kg"}]},
            {"category": "Proteins", "items": [{"name": "Toor Dal (Pigeon Peas)", "quantity": "500g"}, {"name": "Paneer (Indian Cottage Cheese)", "quantity": "200g"}, {"name": "Yogurt (Dahi)", "quantity": "500g"}]},
            {"category": "Grains", "items": [{"name": "Basmati Rice", "quantity": "1kg"}, {"name": "Whole Wheat Flour (Atta)", "quantity": "1kg"}]},
            {"category": "Fats", "items": [{"name": "Ghee", "quantity": "200ml"}, {"name": "Mustard Oil", "quantity": "500ml"}]},
            {"category": "Miscellaneous", "items": [{"name": "Cumin Seeds", "quantity": "50g"}, {"name": "Turmeric Powder", "quantity": "50g"}, {"name": "Green Chilies", "quantity": "100g"}]}
        ]
    }
    
    low_budget_list = {
        "groceryList": [
            {"category": "Vegetables", "items": [{"name": "Potatoes", "quantity": "2kg"}, {"name": "Onions", "quantity": "1kg"}, {"name": "Carrots", "quantity": "1kg"}, {"name": "Cabbage", "quantity": "1 head"}]},
            {"category": "Fruits", "items": [{"name": "Bananas", "quantity": "1 dozen"}, {"name": "Apples", "quantity": "1kg"}]},
            {"category": "Proteins", "items": [{"name": "Dried Lentils", "quantity": "1kg"}, {"name": "Eggs", "quantity": "1 dozen"}, {"name": "Canned Tuna", "quantity": "4 cans"}]},
            {"category": "Grains", "items": [{"name": "Rice", "quantity": "2kg"}, {"name": "Oats", "quantity": "1kg"}, {"name": "Pasta", "quantity": "1kg"}]},
            {"category": "Fats", "items": [{"name": "Vegetable Oil", "quantity": "1 liter"}]},
            {"category": "Miscellaneous", "items": [{"name": "Salt", "quantity": "1kg"}, {"name": "Basic Spices Mix", "quantity": "100g"}]}
        ]
    }

    default_list = {
        "groceryList": [
            {"category": "Vegetables", "items": [{"name": "Spinach", "quantity": "2 bags (200g each)"}, {"name": "Broccoli", "quantity": "2 heads"}, {"name": "Carrots", "quantity": "1 bag (1kg)"}]},
            {"category": "Fruits", "items": [{"name": "Apples", "quantity": "5 medium"}, {"name": "Bananas", "quantity": "1 bunch"}, {"name": "Berries (mixed)", "quantity": "1 container (250g)"}]},
            {"category": "Proteins", "items": [{"name": "Chicken Breast (boneless, skinless)", "quantity": "500g"}, {"name": "Salmon Fillets", "quantity": "2 (150g each)"}, {"name": "Lentils (dried)", "quantity": "1 bag (500g)"}]},
            {"category": "Grains", "items": [{"name": "Quinoa", "quantity": "1 box (500g)"}, {"name": "Oats (rolled)", "quantity": "1 bag (1kg)"}, {"name": "Whole Wheat Bread", "quantity": "1 loaf"}]},
            {"category": "Fats", "items": [{"name": "Avocado", "quantity": "2 medium"}, {"name": "Olive Oil (extra virgin)", "quantity": "1 bottle (500ml)"}, {"name": "Almonds (raw)", "quantity": "1 bag (200g)"}]},
            {"category": "Miscellaneous", "items": [{"name": "Herbs (e.g., parsley, cilantro)", "quantity": "1 bunch"}, {"name": "Spices (e.g., cumin, paprika)", "quantity": "as needed"}]}
        ]
    }

    # --- Logic to select the mock response ---
    if profile.region and "india" in profile.region.lower():
        return GroceryListResponse.model_validate(indian_grocery_list)
    
    if profile.budget_level and profile.budget_level.lower() == "low":
        return GroceryListResponse.model_validate(low_budget_list)

    return GroceryListResponse.model_validate(default_list)

    # --- Original OpenAI Integration (Commented Out) ---
    # prompt = f"""
    # Generate a detailed, categorized grocery list based on the following personalized health, dietary, cultural, and environmental parameters:

    # --- Health & Lifestyle ---
    # Age: {profile.age} years
    # Gender: {profile.gender}
    # Height: {profile.height} cm
    # Weight: {profile.weight} kg
    # Activity Level: {profile.activity_level}
    # Dietary Goals: {profile.dietary_goals}
    # Meal Plan Duration: {profile.meal_plan_duration}

    # --- Health Metrics ---
    # Blood Pressure: Systolic {profile.systolic_bp} mmHg, Diastolic {profile.diastolic_bp} mmHg
    # Blood Sugar Level: {profile.blood_sugar} mg/dL
    # Cholesterol Level: {profile.cholesterol} mg/dL

    # --- Preferences & Constraints ---
    # Dietary Restrictions: {profile.dietary_restrictions}
    # Preferred Cuisines: {profile.preferred_cuisines}
    # Budget Level: {profile.budget_level}
    
    # --- Contextual Factors ---
    # Region & Culture: {profile.region or 'not specified'}
    # Current Weather: {profile.weather or 'not specified'}
    # Seasonal Availability: {profile.regional_seasonal_availability}

    # --- Instructions ---
    # 1.  **Prioritize Health:** Focus on fresh, nutrient-dense foods that support blood pressure normalization, blood sugar regulation, and cholesterol management. Exclude processed, high-sodium, sugary, and saturated fat-rich items.
    # 2.  **Incorporate Context:**
    #     -   If region is specified (e.g., "South India", "Scandinavia"), adapt the list to include common, culturally relevant ingredients.
    #     -   If weather is specified (e.g., "Hot", "Cold"), suggest weather-appropriate foods (e.g., salads and fruits for hot weather, soups and root vegetables for cold weather).
    # 3.  **Provide Quantities:** Estimate quantities for the specified meal plan duration.
    # 4.  **Format Correctly:** Your response MUST be a valid JSON object with a single key "groceryList".
    #     The value of "groceryList" must be an array of objects, each with "category" and "items" keys.
    #     Each item must have a "name" and "quantity".
    #
    # Example Structure:
    # {{
    #   "groceryList": [
    #     {{ "category": "Vegetables", "items": [{{ "name": "Spinach", "quantity": "200g" }}] }}
    #   ]
    # }}
    # """

    # completion = client.chat.completions.create(
    #     model="gpt-4o-mini",
    #     messages=[
    #         {"role": "system", "content": "You are an expert nutritionist creating optimized grocery lists. Your response must be a valid JSON object matching the specified structure."},
    #         {"role": "user", "content": prompt}
    #     ],
    #     response_format={"type": "json_object"}
    # )
    
    # response_content = completion.choices[0].message.content
    
    # # Pydantic will automatically parse and validate the JSON string
    # return GroceryListResponse.model_validate_json(response_content)
